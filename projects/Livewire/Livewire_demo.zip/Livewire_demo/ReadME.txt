======================================================
Anisotropic geodesics for live-wire mesh segmentation
======================================================

This tool is based on our paper: "Yixin Zhuang, Ming Zou, Nathan Carr, Tao Ju. Anisotropic geodesics for live-wire mesh segmentation. Pacific Graphics 2014"

We used the following 3 packages in our project:
1. "TriMesh 2": to computer the curvature. The author is Szymon Rusinkiewicz, and the project can be found from this link “http://gfx.cs.princeton.edu/proj/trimesh2/" 
2. "geodesicDistance": to computer geodesics. It is the code from "Vitaly Surazhsky, Tatiana Surazhsky, Danil Kirsanov, Steven Gortler, Hugues Hoppe. Fast exact and approximate geodesics on meshes. Siggraph2005". We modified their code in our project and adapted it to calculating our own anisotropic geodesics.
3. "CrestCODE": which we used to compare results with. It comes from"YOSHIZAWA S., BELYAEV A., SEIDEL H.-P. Fast and robust detection of crest lines on meshes. SPM2005".

---------------
How to use?

View Operations
1. Rotate: Hold the LEFT button while moving the mouse;
2. Translate: Hold the MIDDLE button while moving the mouse;
3. Scale: Hold the RIGHT button while moving the mouse up and down; or Hold the RIGHT Button while scrolling the MIDDLE button;
4. Turn on/off full screen: Double-click the visualization panel.

Drawing Operations
1. Put down a seed: Press the CTRL key and click the LEFT button;
2. Explore curves from current seed: After placing a seed, hold the CTRL key while moving the mouse;
3. Start a new curve: Press the CTRL key and click the RIGHT button;

Curve Editing
1. Select a curve: Hold the ALT key while moving the mouse to the curve to be selected;
2. Delete a curve: Hole the ALT key and click on he curve to be deleted with the LEFT button;

Scribbling Operations
1: Scribble: Hold the SHIFT key and the LEFT button while moving the mouse;
2: Finish: Press the SHIFT key and click the RIGHT button; or just release the SHIFT key;

Saving Results
1. Save curve network: Find “Save Curve Network” on Menu, the select a file type to save (e.g. *.paths);
2. Save patches: Use "Make Patch" Button on the control panel to extract and save patches (patches are saved as .obj with the “group” label);

More Advanced Operations
1. Curvature parameter (set to be 0.1 by default). When the parameter is small, features are more obvious, but the curvature direction may not be globally consistent. When it is large, features may be smoothed out.
2. Metric parameter (set to be 0.1 by default). Increasing the parameter leads to larger anisotropic metric, which means that ”wires" will snap to mesh features easier.
3. Visualization of anisotropic metrics. First activate an anisotropy metric (e.g. Euclidean, Ours, Kovacs or Campen’s). The metric field is plotted with ellipse-shaped tensors on each vertex of the mesh; the distance field can be visualized with single-source-all-destination paths or isolines.
