

How to Run:
-------------------

1.Load a file. This operation will construct the curve network and find cycles.
2.Change viewpoint, cycle size and color mode to get a better visualization of cycles. 

3.Check whether all cycles are correct, if incorrect cycle exists, apply constraint by selecting partial or full cycles in the curve network, or change capacity of non-manifold curves. (please refer to our video to see how these are done)



Hotkeys:
-------------------
1. Ctrl + ...	(Button)

	Ctrl+L -> (L)oad file;
	Ctrl+S -> (S)ave file;
	Ctrl+C -> (C)onstraint;
	Ctrl+A -> C(A)pacity;
	Ctrl+P -> (P)arameter;

2. One Key	(CheckBox)

	A -> Show/Hide CurveNetwork��(A)rcs;
	C -> Show/Hide (C)ycle;
	S -> Show/Hide (S)urface;
	N -> Change to Si(N)gle Cycle Mode;
	
3. Shift + ...	(RadioBox)

	Shift+A -> Change Mode of CurveNetwork��(A)rc;
	Shift+C -> Change Mode of (C)ycle;
	Shift+S -> Change Mode of (S)urface;

4. One Key	(SpinButton)
		Right Hand
	Left -> Increase Cycle Size;
	Right-> Decrease Cycle Size;
	Up   -> Increase Line Width;
	Down -> Decrease Line Width;

5. One Key	(Others)

	Del  -> In cycle constraint mode, to remove the latest constraint;
	Esc  -> Exit;
	Home -> Full Screen; 
	1/2/3-> Get to curve/cycle/surface visualization mode
	4    -> Back from 1/2/3 mode
	R    -> Rotation mode
	9    -> Screen shot
	0    -> Show normals

6. With Mouse

	Ctrl + Mouse Move -> View Single Arc (when In Capacity and Constraint Mode);
	Ctrl + Mouse Left -> Select Arcs (when In Constraint Mode);
	Ctrl + Mouse Wheel-> Increase the capacity of Selected Arcs (when In Capacity Mode);
 	Alt  + Mouse Move -> View Single Cycle (when In Single Cycle Mode);


